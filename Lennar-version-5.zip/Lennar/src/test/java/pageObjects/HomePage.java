package pageObjects;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;


public class HomePage {

	public WebDriver ldriver;
	WebDriverWait wait;
	public boolean flag;
	public WebElement staricon;
	
	
	public HomePage(WebDriver rdriver) {
		
		ldriver = rdriver;
		PageFactory.initElements(rdriver, this);
		
	}
	
	@FindBy(id="input28")
	WebElement txtEmail;
	
	@FindBy(xpath="//input[@value='Next']")
	WebElement btnEmail;
	
	@FindBy(id="input60")
	WebElement txtPass;
	
	@FindBy(xpath="//form[@id='form52']/div[2]/input")
	WebElement btnPass;
	
	@FindBy(xpath="//div[@class='Favorites']")
	WebElement tabFavorites;
	
	@FindBy(xpath="//div[@class='RecentForecast']/p")
	WebElement labelFavorites;

	@FindBy(xpath="//div[@class='RecentsAndFavorites']/div[text()='Recent Forecast']")
	WebElement tabRecents;
	
	@FindBy(xpath="//div[@class='ForecastTile']")
	List<WebElement> myElements;
	
	@FindBy(xpath="//span[text() = 'VIRTUAL LUMBERYARD DEV']")	      
	WebElement btnVly;
	
	@FindBy(xpath="//p[text()='View All']")
	WebElement btnViewAll;
	
	@FindBy(xpath="//div[@class='createForcast_CreateForecast__qhZj+']/button")
	WebElement btnNewForecast;
	
	@FindBy(xpath="//div[@data-testid='create-forecast-select-dealers']")
	WebElement selectDealer;
	
	@FindBy(xpath="//ul[@role='listbox']/li[text()='84 Lumber']")
	WebElement dealer84Lumber;
	
	@FindBy(xpath="//button[text()='Proceed']")
	WebElement btnProceed;
	
	
	
	
	public void waitForWebElement(WebElement element) {
		wait = new WebDriverWait(ldriver, java.time.Duration.ofSeconds(30));
        wait.until(ExpectedConditions.elementToBeClickable(element));
		
	}
	
	public void waitForWebElements(List<WebElement> elements) {
		wait = new WebDriverWait(ldriver, java.time.Duration.ofSeconds(30));
        wait.until(ExpectedConditions.visibilityOfAllElements(elements));
		
	}
	
	
	public void setUserName(String userName) throws InterruptedException{
		waitForWebElement(txtEmail);
		txtEmail.clear();
		txtEmail.sendKeys(userName);
	
	}
	
	public void setPassword(String pwd) throws InterruptedException{
		waitForWebElement(txtPass);
		txtPass.clear();
		txtPass.sendKeys(pwd);
	}
	
	
	public void clickNextButton(){
		
		btnEmail.click();
	}
	
	public void clickLoginButton(){
		
		btnPass.click();
	}
	

	
	public void createforecastWithoutFile() throws InterruptedException{
		waitForWebElement(btnNewForecast);
		btnNewForecast.click();
		waitForWebElement(selectDealer);
		selectDealer.click();
		waitForWebElement(dealer84Lumber);
		dealer84Lumber.click();
		Thread.sleep(2000);
		btnProceed.click();
	}
	
	public void clickLogoVly(){
		waitForWebElement(btnVly);
		btnVly.click();
	}
	
	
	public void searchTabFavorites(){
		waitForWebElement(tabFavorites);
		tabFavorites.click();
	}
	
	public void checkIfSaveFavoritesForecast(){
		waitForWebElement(labelFavorites);
		
		if(labelFavorites.isDisplayed()) {
			String ExpectedTitle = "You don't have any favorite forecasts.";
			String ActualTitle = labelFavorites.getText();
			Assert.assertEquals(ExpectedTitle, ActualTitle);
			System.out.println("You dont have saved favorite forecast");
			flag = true;
		
		} else {
			System.out.println("You have saved favorite forecast");
		}
			
	}
	
	public void searchTabRecentForecast(){
		waitForWebElement(tabRecents);
		tabRecents.click();
	}
	
	
	public void addFavoriteForecast() throws InterruptedException {
		 Thread.sleep(1000);		
		 int count = myElements.size();
		 
		for(int i = 1; i<=count; i++) { 
			 staricon = ldriver.findElement(By.xpath("(//button[@class='MuiButtonBase-root MuiIconButton-root MuiIconButton-sizeMedium css-1yxmbwk'])["+i+"]"));	
			 staricon.click();
			 Thread.sleep(1500);
			 
		}
		
	}
	
	public void clickOnAllFavoriteForecast() throws InterruptedException {
		
		waitForWebElement(btnViewAll);
		btnViewAll.click();
		Thread.sleep(2000);
		
	}
	
	
	
	
	
}