package pageObjects;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;


public class LoginPage {

	public WebDriver ldriver;
	WebDriverWait wait;
	
	public LoginPage(WebDriver rdriver) {
		
		ldriver = rdriver;
		PageFactory.initElements(rdriver, this);
		
	}
	
	@FindBy(id="input28")
	WebElement txtEmail;
	
	@FindBy(xpath="//input[@value='Next']")
	WebElement btnEmail;
	
	@FindBy(id="input60")
	WebElement txtPass;
	
	@FindBy(xpath="//form[@id='form52']/div[2]/input")
	WebElement btnPass;
		
	@FindBy(xpath="//span[text() = 'VIRTUAL LUMBERYARD DEV']")
	WebElement btnVly;
	
	public void setUserName(String userName){
		waitForWebElement(txtEmail);
		txtEmail.clear();
		txtEmail.sendKeys(userName);
	
	}
	
	public void setPassword(String pwd){
		waitForWebElement(txtPass);
		txtPass.clear();
		txtPass.sendKeys(pwd);
	}
	
	
	public void clickNextButton(){
		
		btnEmail.click();
	}
	
	public void clickLoginButton(){
		
		btnPass.click();
	}
	
	public void clickLogoVly(){
		waitForWebElement(btnVly);
		btnVly.click();
	}
	
	
	public void waitForWebElement(WebElement element) {
		wait = new WebDriverWait(ldriver, java.time.Duration.ofSeconds(30));
        wait.until(ExpectedConditions.elementToBeClickable(element));
		
	}
	
	
	
	
}