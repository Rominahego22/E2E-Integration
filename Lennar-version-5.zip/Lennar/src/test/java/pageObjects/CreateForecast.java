package pageObjects;

import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class CreateForecast {
	
	public WebDriver ldriver;
	WebDriverWait wait;
	
	
	public CreateForecast(WebDriver rdriver) {
		
		ldriver = rdriver;
		PageFactory.initElements(rdriver, this);
		
	}
	
	@FindBy(xpath="//button[text()='Save']")
	WebElement btnSaveForecast;
	
	@FindBy(xpath="//div[@class='button-container']/button[text()='Save']")
	WebElement btnSaveDialogForecast;
	
	@FindBy(css="div.MuiBox-root.css-7pktlf svg")
	WebElement btnHome;
	
	
	public void waitForWebElement(WebElement element) {
		wait = new WebDriverWait(ldriver, java.time.Duration.ofSeconds(30));
        wait.until(ExpectedConditions.elementToBeClickable(element));
		
	}
	
	public void waitForWebElements(List<WebElement> elements) {
		wait = new WebDriverWait(ldriver, java.time.Duration.ofSeconds(30));
        wait.until(ExpectedConditions.visibilityOfAllElements(elements));
		
	}
	
	public void saveSimpleForecast() throws InterruptedException {
		
		waitForWebElement(btnSaveForecast);
		btnSaveForecast.click();
		waitForWebElement(btnSaveDialogForecast);
		btnSaveDialogForecast.click();
		Thread.sleep(2000);
		btnHome.click();
		
		
	}
	
	

}
