package stepDefinitions;

import io.cucumber.java.After;
import io.cucumber.java.Before;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import pageObjects.CreateForecast;
import pageObjects.HomePage;
import pageObjects.LoginPage;

import java.util.Iterator;
import java.util.List;
import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.Assert;

import Driver.Driver;


public class Steps {

    public WebDriver driver;
    public LoginPage lp;
    public String userEmail = "luis.navarromedina@lennar.com";
    public String userPwd = "Tommy25.*";
    public HomePage hp;
    public CreateForecast cf;

    @Before
    public void browserSetup() {
        Driver objectWebDriver = new Driver();
        driver = objectWebDriver.objectDriver();

    }

    @After
    public void shutdown() throws InterruptedException {
    	Thread.sleep(5000);
     	driver.close();
     	driver.quit();
    	
    }
    
    @Given("User Launch Firefox")
    public void user_launch_firefox() {

         lp = new LoginPage(driver);
         hp = new HomePage(driver);  
         cf = new CreateForecast(driver);
    }
    
    @When("User opens URL")
    public void user_opens_url() {
    	 driver.get("https://lennar.okta.com/app/UserHome");
    }

    @When("User enters an Email")
    public void user_enters_an_email() {     
    	lp.setUserName(userEmail);  	
    }

    @When("Click on Next")
    public void click_on_next() {
    	lp.clickNextButton();
    }

    @When("User enters a Password")
    public void user_enters_a_password() {
        lp.setPassword(userPwd);
    }

    @When("Click on Verify btn")
    public void click_on_verify_btn() {
       lp.clickLoginButton();
    }
   
    @Then("Click on Logo Vly")
    public void click_on_logo_vly() throws InterruptedException {
    	Thread.sleep(2000);
    	lp.clickLogoVly();
    }
  
    @Then("Change window")
    public void change_window() {
    	String parent=driver.getWindowHandle();

    	Set<String>windows=driver.getWindowHandles();
    	
    	Iterator<String>it = windows.iterator();
    	
    	while(it.hasNext()) {
    		
    			String currentWindow = it.next();
    			if(!parent.equals(currentWindow)) {
    				
    			  driver.switchTo().window(currentWindow).manage().window().maximize();
    			
    			  
    			}
    	}
    }

    @Then("Validate name of tab")
    public void validate_name_of_tab() throws InterruptedException {
    	
    	Thread.sleep(2000);
    	String actualTitle = driver.getTitle();
    	String ExpectedTitle = "Virtual Lumberyard";
    
		Assert.assertEquals(ExpectedTitle, actualTitle);
    	    
    }

    
    @When("Search the label Favorites tab and click it")
    public void search_the_label_favorites_tab_and_click_it() {
    	hp.searchTabFavorites(); 
    }

    @When("Check if you have favorite forecast saved")
    public void check_if_you_have_favorite_forecast_saved() {
    	hp.checkIfSaveFavoritesForecast();
    
    }

    @When("Change to the Recent Forecast tab and click it")
    public void change_to_the_recent_forecast_tab_and_click_it() {
    	hp.searchTabRecentForecast();
    }

    @When("Click on the star icon ten times")
    public void click_on_the_star_icon_ten_times() throws InterruptedException {
    	hp.addFavoriteForecast();
    
    }
    
    @When("Click on the view all forecast label")
    public void click_on_the_view_all_forecast_label() throws InterruptedException {
       hp.clickOnAllFavoriteForecast();
    	
    }

    @When("Go to the third pagination")
    public void go_to_the_third_pagination() throws InterruptedException {

    	WebElement drop = driver.findElement(By.xpath("(//div[contains(@class,'MuiSelect-select')])[2]"));
    	drop.sendKeys(Keys.ENTER);
    	driver.findElement(By.xpath("//ul[@class='MuiList-root MuiList-padding MuiMenu-list css-r8u8y9']/li[3]")).click();
    	
    
    }

    @When("add One more favorite forecast")
    public void add_one_more_favorite_forecast() {
    	
       driver.findElement(By.xpath("(//button[@class='MuiButtonBase-root MuiIconButton-root MuiIconButton-sizeMedium css-1yxmbwk'])[3]")).click();
       String actualMessage = driver.findElement(By.xpath("//div[@class='MuiAlert-message css-1xsto0d']")).getText();
       String expectedMessage = "Max favorites allowed has been reached, remove a forecast from favorites to add new.";
       Assert.assertEquals(expectedMessage, actualMessage);

    }

    
    @Then("Search and click on View All Forecast")
    public void search_and_click_on_view_all_forecast() throws InterruptedException {
      hp.clickOnAllFavoriteForecast();
  	  Thread.sleep(4000);
  	  List<WebElement> forecastList= driver.findElements(By.xpath("//div[@class='ForecastTile']"));
  	  int sizeActual = forecastList.size();
  	  int sizeExpected = 20;
  	
		Assert.assertEquals(sizeExpected, sizeActual);

    }
    
    @When("User clicks on create forecast button")
    public void user_clicks_on_create_forecast_button() throws InterruptedException {
    	hp.createforecastWithoutFile();
        
    }
    
    @When("User are in add forecast page click on save button")
    public void user_are_in_add_forecast_page_click_on_save_button() throws InterruptedException {
    	
    	cf.saveSimpleForecast();
    }





  

}
