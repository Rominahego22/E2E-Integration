package testRunner;
import io.cucumber.junit.CucumberOptions;
import org.junit.runner.RunWith;
import io.cucumber.junit.Cucumber;


@RunWith(Cucumber.class)
@CucumberOptions(
features="src/test/resources/Features/LennarLogin.feature",
glue = "stepDefinitions",
dryRun=false,
monochrome=true,
stepNotifications = true,
plugin={"junit:reports/junit/reports.xml",
"pretty:target/cucumber-pretty.text",
"html:target/cucumber-html-report",
"json:target/cucumber.json",
"usage:target/cucumber-usage.json",}
// monochrome = true,
// strict = true,
// dryRun = false

)
public class LennarLogin {
}