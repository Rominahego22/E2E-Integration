package Driver;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;


public class Driver {

    public WebDriver objectDriver(){
        System.setProperty("webdriver.gecko.driver","C:\\Users\\LMedina\\eclipse-workspace\\Lennar\\Drivers\\geckodriver.exe");
        
      /* FirefoxOptions option = new FirefoxOptions();
        option.addArguments("-private");
        WebDriverManager.firefoxdriver().setup(); */
        
        WebDriver driver = new FirefoxDriver();
        driver.manage().window().maximize();
        return driver;
    }

}
