module.exports = {
    default: `--format-options '{"snippetInterface": "synchronous"}'`
  }